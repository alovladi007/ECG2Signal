"""
Temporary file utilities for ECG2Signal.

Provides safe temporary file/directory creation and cleanup.
"""
import tempfile
import shutil
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)


def create_temp_dir(prefix: str = 'ecg2signal_') -> Path:
    """
    Create a temporary directory.
    
    Args:
        prefix: Prefix for the directory name
    
    Returns:
        Path to the created temporary directory
    """
    temp_dir = Path(tempfile.mkdtemp(prefix=prefix))
    logger.debug(f"Created temporary directory: {temp_dir}")
    return temp_dir


def cleanup_temp_files(path: Path, ignore_errors: bool = True) -> None:
    """
    Cleanup temporary files or directories.
    
    Args:
        path: Path to file or directory to remove
        ignore_errors: If True, ignore errors during cleanup
    """
    try:
        if path.exists():
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=ignore_errors)
                logger.debug(f"Removed temporary directory: {path}")
            else:
                path.unlink(missing_ok=True)
                logger.debug(f"Removed temporary file: {path}")
    except Exception as e:
        if not ignore_errors:
            raise
        logger.warning(f"Failed to cleanup {path}: {e}")


def create_temp_file(suffix: str = '', prefix: str = 'ecg2signal_', dir: Optional[Path] = None) -> Path:
    """
    Create a temporary file.
    
    Args:
        suffix: Suffix for the filename (e.g., '.jpg')
        prefix: Prefix for the filename
        dir: Directory to create the file in (default: system temp)
    
    Returns:
        Path to the created temporary file
    """
    fd, path = tempfile.mkstemp(suffix=suffix, prefix=prefix, dir=str(dir) if dir else None)
    import os
    os.close(fd)  # Close file descriptor
    temp_path = Path(path)
    logger.debug(f"Created temporary file: {temp_path}")
    return temp_path

