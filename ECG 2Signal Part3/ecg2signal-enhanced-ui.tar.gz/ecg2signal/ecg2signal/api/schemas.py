"""
Pydantic schemas for ECG2Signal API.
"""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum


class ExportFormat(str, Enum):
    """Supported export formats."""
    WFDB = "wfdb"
    CSV = "csv"
    JSON = "json"
    EDF = "edf"
    FHIR = "fhir"
    DICOM = "dicom"


class ConversionRequest(BaseModel):
    """Request schema for ECG conversion."""
    paper_speed: float = Field(25.0, description="Paper speed in mm/s", ge=10.0, le=100.0)
    gain: float = Field(10.0, description="Gain in mm/mV", ge=2.5, le=40.0)
    export_format: ExportFormat = Field(ExportFormat.WFDB, description="Output format")
    include_quality_metrics: bool = Field(True, description="Include QC metrics")
    extract_clinical_intervals: bool = Field(True, description="Extract PR, QRS, QT intervals")


class LeadSignal(BaseModel):
    """Schema for a single lead signal."""
    lead_name: str
    samples: List[float]
    sampling_rate: float
    units: str = "mV"
    duration: float  # seconds


class ClinicalIntervals(BaseModel):
    """Clinical interval measurements."""
    heart_rate: Optional[float] = Field(None, description="Heart rate in BPM")
    pr_interval: Optional[float] = Field(None, description="PR interval in ms")
    qrs_duration: Optional[float] = Field(None, description="QRS duration in ms")
    qt_interval: Optional[float] = Field(None, description="QT interval in ms")
    qtc_interval: Optional[float] = Field(None, description="Corrected QT interval in ms")


class QualityMetrics(BaseModel):
    """Signal quality metrics."""
    overall_quality: float = Field(..., ge=0.0, le=1.0, description="Overall quality score")
    snr: Optional[float] = Field(None, description="Signal-to-noise ratio in dB")
    baseline_wander: Optional[float] = Field(None, description="Baseline wander score")
    clipping_detected: bool = Field(False, description="Whether clipping was detected")
    coverage: float = Field(..., ge=0.0, le=1.0, description="Signal coverage ratio")


class CalibrationInfo(BaseModel):
    """Calibration information from the ECG image."""
    paper_speed: float  # mm/s
    gain: float  # mm/mV
    pixels_per_mm: float
    detected_grid: bool


class ConversionResult(BaseModel):
    """Result of ECG conversion."""
    status: str
    leads: List[LeadSignal]
    calibration: CalibrationInfo
    clinical_intervals: Optional[ClinicalIntervals] = None
    quality_metrics: Optional[QualityMetrics] = None
    export_files: Optional[Dict[str, str]] = Field(None, description="Paths to exported files")
    warnings: List[str] = Field(default_factory=list)


class BatchConversionRequest(BaseModel):
    """Request schema for batch ECG conversion."""
    file_ids: List[str] = Field(..., description="List of uploaded file IDs")
    paper_speed: float = Field(25.0, ge=10.0, le=100.0)
    gain: float = Field(10.0, ge=2.5, le=40.0)
    export_format: ExportFormat = ExportFormat.WFDB


class BatchConversionResult(BaseModel):
    """Result of batch conversion."""
    status: str
    total: int
    successful: int
    failed: int
    results: List[Dict[str, Any]]


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    version: str
    models_loaded: bool
    uptime_seconds: Optional[float] = None


class ErrorResponse(BaseModel):
    """Error response schema."""
    error: str
    detail: Optional[str] = None
    status_code: int
