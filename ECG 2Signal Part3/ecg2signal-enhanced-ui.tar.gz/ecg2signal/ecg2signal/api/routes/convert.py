"""
Convert endpoint for ECG image to signal conversion.
"""
import tempfile
import shutil
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, File, UploadFile, Form, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
import logging

from ecg2signal.api.schemas import (
    ConversionResult, ExportFormat, LeadSignal, CalibrationInfo,
    ClinicalIntervals, QualityMetrics, ErrorResponse
)
from ecg2signal.config import get_settings
from ecg2signal.io import image_io, pdf
from ecg2signal.preprocess import detect_page, dewarp, denoise, grid_detect, scale_calibrate
from ecg2signal.layout import lead_layout, ocr_labels
from ecg2signal.segment import separate_layers, trace_curve
from ecg2signal.reconstruct import raster_to_signal, resample, align_leads, postprocess
from ecg2signal.clinical import intervals, quality as qc
from ecg2signal.io import wfdb_io, edf_io, dcm_waveform, fhir as fhir_io
from ecg2signal.utils.tempfile_utils import cleanup_temp_files

router = APIRouter(prefix="/convert", tags=["conversion"])
logger = logging.getLogger(__name__)
settings = get_settings()


def cleanup_temp_directory(temp_dir: Path):
    """Background task to cleanup temporary files."""
    try:
        if temp_dir.exists():
            shutil.rmtree(temp_dir)
    except Exception as e:
        logger.warning(f"Failed to cleanup temp dir {temp_dir}: {e}")


@router.post("/", response_model=ConversionResult)
async def convert_ecg(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(..., description="ECG image (JPG/PNG/TIFF) or PDF"),
    paper_speed: float = Form(25.0, description="Paper speed in mm/s", ge=10.0, le=100.0),
    gain: float = Form(10.0, description="Gain in mm/mV", ge=2.5, le=40.0),
    export_format: ExportFormat = Form(ExportFormat.WFDB, description="Export format"),
    include_quality: bool = Form(True, description="Include quality metrics"),
    extract_intervals: bool = Form(True, description="Extract clinical intervals"),
):
    """
    Convert an ECG image or PDF to digital time-series signals.
    
    Supports:
    - Image formats: JPG, PNG, TIFF
    - PDF (single or multi-page)
    - Mobile photos with perspective distortion
    - Color or grayscale images
    - With or without grid
    
    Returns digitized signals with calibration, quality metrics, and clinical intervals.
    """
    temp_dir = Path(tempfile.mkdtemp(prefix="ecg2signal_"))
    background_tasks.add_task(cleanup_temp_directory, temp_dir)
    
    try:
        # Save uploaded file
        file_path = temp_dir / file.filename
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        logger.info(f"Processing file: {file.filename}")
        
        # Handle PDF -> extract first page as image
        if file.filename.lower().endswith('.pdf'):
            images = pdf.pdf_to_images(str(file_path))
            if not images:
                raise HTTPException(status_code=400, detail="No pages found in PDF")
            image = images[0]
            image_path = temp_dir / "page_0.png"
            image_io.save_image(image, str(image_path))
        else:
            image = image_io.load_image(str(file_path))
            image_path = file_path
        
        warnings = []
        
        # Step 1: Preprocessing
        logger.info("Step 1: Preprocessing")
        page_img = detect_page.detect_and_crop_page(image)
        if page_img.shape != image.shape:
            warnings.append("Page border detected and cropped")
        
        dewarped_img = dewarp.correct_perspective(page_img)
        clean_img = denoise.denoise_image(dewarped_img)
        
        # Step 2: Grid detection and calibration
        logger.info("Step 2: Grid detection and calibration")
        grid_info = grid_detect.detect_grid(clean_img)
        
        if grid_info is None:
            warnings.append("No grid detected, using provided calibration values")
            calibration = scale_calibrate.CalibrationResult(
                pixels_per_mm=10.0,  # Default estimate
                paper_speed=paper_speed,
                gain=gain,
                detected_grid=False
            )
        else:
            calibration = scale_calibrate.calibrate_from_grid(
                grid_info,
                paper_speed=paper_speed,
                gain=gain
            )
        
        # Step 3: Layout detection and OCR
        logger.info("Step 3: Layout detection")
        layout = lead_layout.detect_lead_layout(clean_img)
        
        # Try to extract paper speed/gain from image
        ocr_result = ocr_labels.extract_labels(clean_img)
        if ocr_result.get('paper_speed'):
            calibration.paper_speed = ocr_result['paper_speed']
            warnings.append(f"Paper speed detected from image: {ocr_result['paper_speed']} mm/s")
        if ocr_result.get('gain'):
            calibration.gain = ocr_result['gain']
            warnings.append(f"Gain detected from image: {ocr_result['gain']} mm/mV")
        
        # Step 4: Segmentation and trace extraction
        logger.info("Step 4: Segmentation")
        masks = separate_layers.segment_layers(clean_img)
        waveform_mask = masks['waveform']
        
        # Step 5: Signal reconstruction
        logger.info("Step 5: Signal reconstruction")
        lead_signals = []
        
        for lead_name, roi in layout.items():
            # Extract trace from this lead's region
            lead_mask = waveform_mask[roi['y1']:roi['y2'], roi['x1']:roi['x2']]
            curve = trace_curve.trace_waveform(lead_mask)
            
            # Convert pixels to signal
            signal = raster_to_signal.pixels_to_signal(
                curve,
                calibration,
                roi_offset=(roi['x1'], roi['y1'])
            )
            
            # Resample to standard rate (500 Hz)
            resampled = resample.resample_signal(signal, target_fs=500.0)
            
            # Post-process (filter, baseline removal)
            clean_signal = postprocess.postprocess_signal(resampled)
            
            lead_signals.append(LeadSignal(
                lead_name=lead_name,
                samples=clean_signal.tolist(),
                sampling_rate=500.0,
                units="mV",
                duration=len(clean_signal) / 500.0
            ))
        
        # Align leads if multiple
        if len(lead_signals) > 1:
            aligned = align_leads.align_all_leads([ls.samples for ls in lead_signals])
            for i, lead_sig in enumerate(lead_signals):
                lead_sig.samples = aligned[i].tolist()
        
        # Step 6: Clinical features (if requested)
        clinical_intervals = None
        if extract_intervals and lead_signals:
            try:
                # Use Lead II or first available lead
                lead_ii = next((ls for ls in lead_signals if ls.lead_name == "II"), lead_signals[0])
                intervals_result = intervals.extract_intervals(
                    lead_ii.samples,
                    fs=lead_ii.sampling_rate
                )
                clinical_intervals = ClinicalIntervals(**intervals_result)
            except Exception as e:
                logger.warning(f"Failed to extract clinical intervals: {e}")
                warnings.append("Clinical interval extraction failed")
        
        # Step 7: Quality metrics (if requested)
        quality_metrics = None
        if include_quality and lead_signals:
            try:
                quality_result = qc.assess_quality([ls.samples for ls in lead_signals])
                quality_metrics = QualityMetrics(**quality_result)
            except Exception as e:
                logger.warning(f"Failed to compute quality metrics: {e}")
                warnings.append("Quality assessment failed")
        
        # Step 8: Export to requested format
        logger.info(f"Step 8: Export to {export_format}")
        export_files = {}
        output_base = temp_dir / "ecg_output"
        
        # Prepare signals dict for export
        signals_dict = {ls.lead_name: ls.samples for ls in lead_signals}
        fs = lead_signals[0].sampling_rate if lead_signals else 500.0
        
        if export_format == ExportFormat.WFDB:
            wfdb_io.write_wfdb(signals_dict, str(output_base), fs=fs)
            export_files['dat'] = f"{output_base}.dat"
            export_files['hea'] = f"{output_base}.hea"
        
        elif export_format == ExportFormat.CSV:
            import pandas as pd
            df = pd.DataFrame(signals_dict)
            csv_path = f"{output_base}.csv"
            df.to_csv(csv_path, index=False)
            export_files['csv'] = csv_path
        
        elif export_format == ExportFormat.EDF:
            edf_path = f"{output_base}.edf"
            edf_io.write_edf(signals_dict, edf_path, fs=fs)
            export_files['edf'] = edf_path
        
        elif export_format == ExportFormat.FHIR:
            fhir_json = fhir_io.to_fhir_observation(
                signals_dict, fs=fs,
                patient_id=ocr_result.get('patient_id', 'unknown')
            )
            fhir_path = f"{output_base}.json"
            import json
            with open(fhir_path, 'w') as f:
                json.dump(fhir_json, f, indent=2)
            export_files['fhir'] = fhir_path
        
        elif export_format == ExportFormat.DICOM:
            dcm_path = f"{output_base}.dcm"
            dcm_waveform.write_dicom_waveform(
                signals_dict, dcm_path, fs=fs,
                patient_name=ocr_result.get('patient_name', 'Anonymous')
            )
            export_files['dicom'] = dcm_path
        
        logger.info("Conversion completed successfully")
        
        return ConversionResult(
            status="success",
            leads=lead_signals,
            calibration=CalibrationInfo(
                paper_speed=calibration.paper_speed,
                gain=calibration.gain,
                pixels_per_mm=calibration.pixels_per_mm,
                detected_grid=calibration.detected_grid
            ),
            clinical_intervals=clinical_intervals,
            quality_metrics=quality_metrics,
            export_files=export_files,
            warnings=warnings
        )
    
    except Exception as e:
        logger.error(f"Conversion failed: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Conversion failed: {str(e)}"
        )


@router.post("/download/{file_type}")
async def download_converted(
    file_type: str,
    file_path: str = Form(..., description="Path to the file to download")
):
    """
    Download converted file.
    
    Args:
        file_type: Type of file (wfdb, csv, edf, fhir, dicom)
        file_path: Path to the file
    """
    path = Path(file_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    media_types = {
        'csv': 'text/csv',
        'json': 'application/json',
        'fhir': 'application/fhir+json',
        'edf': 'application/octet-stream',
        'dicom': 'application/dicom',
        'dat': 'application/octet-stream',
        'hea': 'text/plain'
    }
    
    media_type = media_types.get(file_type, 'application/octet-stream')
    
    return FileResponse(
        path,
        media_type=media_type,
        filename=path.name
    )
