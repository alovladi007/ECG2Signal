"""
FastAPI application for ECG2Signal.

Production-grade API with modular routes, proper error handling,
and comprehensive health checks.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import logging

from ecg2signal import __version__
from ecg2signal.config import get_settings
from ecg2signal.api.routes import convert_router, batch_router, health_router
from ecg2signal.logging_conf import setup_logging

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)

# Get settings
settings = get_settings()

# Create FastAPI application
app = FastAPI(
    title="ECG2Signal API",
    version=__version__,
    description="Convert ECG images to digital time-series signals",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Exception handlers
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Global exception handler for unhandled errors."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "detail": str(exc)}
    )


# Include routers
app.include_router(health_router)
app.include_router(convert_router)
app.include_router(batch_router)


# Root endpoint
@app.get("/")
def root():
    """Root endpoint with API information."""
    return {
        "name": "ECG2Signal API",
        "version": __version__,
        "description": "Convert ECG images to digital signals",
        "docs": "/docs",
        "health": "/health"
    }


# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    """Application startup tasks."""
    logger.info(f"Starting ECG2Signal API v{__version__}")
    # Load models, initialize resources, etc.


@app.on_event("shutdown")
async def shutdown_event():
    """Application shutdown tasks."""
    logger.info("Shutting down ECG2Signal API")
    # Cleanup resources, close connections, etc.
