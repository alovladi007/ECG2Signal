
def generate_pdf_report(ecg_result, output_path: str) -> None:
    pass
