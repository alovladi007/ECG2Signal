"""
Training script for Transformer OCR engine.

Extracts lead labels, paper speed, gain, patient info, and timestamps
from ECG images using a lightweight transformer-based architecture.
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from pathlib import Path
import yaml
from typing import Dict, List, Tuple
import logging
from tqdm import tqdm
import numpy as np

from ecg2signal.training.datasets import OCRDataset
from ecg2signal.training.augment import get_augmentation_pipeline
from ecg2signal.training.metrics import compute_edit_distance, compute_cer
from ecg2signal.config import get_settings

logger = logging.getLogger(__name__)


class TransformerOCR(nn.Module):
    """
    Transformer-based OCR for ECG metadata extraction.
    
    Architecture:
    - CNN encoder: Extract visual features from text regions
    - Transformer encoder: Context-aware feature encoding
    - Transformer decoder: Sequence generation with attention
    - CTC loss for sequence-to-sequence learning
    """
    
    def __init__(
        self,
        vocab_size: int,
        d_model: int = 256,
        nhead: int = 8,
        num_encoder_layers: int = 4,
        num_decoder_layers: int = 4,
        dim_feedforward: int = 1024,
        dropout: float = 0.1,
        max_seq_length: int = 100
    ):
        super().__init__()
        
        self.d_model = d_model
        self.max_seq_length = max_seq_length
        
        # CNN encoder for visual features
        self.cnn_encoder = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            
            nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            
            nn.Conv2d(256, d_model, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
        )
        
        # Positional encoding
        self.pos_encoder = PositionalEncoding(d_model, dropout)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=num_encoder_layers
        )
        
        # Transformer decoder
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True
        )
        self.transformer_decoder = nn.TransformerDecoder(
            decoder_layer,
            num_layers=num_decoder_layers
        )
        
        # Output projection
        self.output_projection = nn.Linear(d_model, vocab_size)
        
        # Embeddings for decoder
        self.embedding = nn.Embedding(vocab_size, d_model)
        self.vocab_size = vocab_size
    
    def forward(
        self,
        images: torch.Tensor,
        target_seq: torch.Tensor = None
    ) -> torch.Tensor:
        """
        Args:
            images: (batch, 1, height, width) - input images
            target_seq: (batch, seq_len) - target sequences for teacher forcing
        
        Returns:
            (batch, seq_len, vocab_size) - predicted logits
        """
        batch_size = images.size(0)
        
        # Extract visual features
        features = self.cnn_encoder(images)  # (B, d_model, H', W')
        
        # Flatten spatial dimensions
        B, C, H, W = features.shape
        features = features.permute(0, 2, 3, 1).reshape(B, H * W, C)  # (B, H'*W', d_model)
        
        # Add positional encoding and encode
        features = self.pos_encoder(features)
        memory = self.transformer_encoder(features)  # (B, H'*W', d_model)
        
        # Decoder
        if target_seq is not None:
            # Teacher forcing during training
            tgt_emb = self.embedding(target_seq)  # (B, seq_len, d_model)
            tgt_emb = self.pos_encoder(tgt_emb)
            
            # Create causal mask
            tgt_mask = self._generate_square_subsequent_mask(target_seq.size(1)).to(images.device)
            
            output = self.transformer_decoder(
                tgt_emb,
                memory,
                tgt_mask=tgt_mask
            )  # (B, seq_len, d_model)
        else:
            # Autoregressive generation during inference
            output = self._generate_sequence(memory, images.device)
        
        # Project to vocabulary
        logits = self.output_projection(output)  # (B, seq_len, vocab_size)
        
        return logits
    
    def _generate_square_subsequent_mask(self, sz: int) -> torch.Tensor:
        """Generate causal mask for decoder."""
        mask = torch.triu(torch.ones(sz, sz), diagonal=1).bool()
        return mask
    
    def _generate_sequence(
        self,
        memory: torch.Tensor,
        device: torch.device,
        max_len: int = None
    ) -> torch.Tensor:
        """
        Autoregressive generation.
        
        Args:
            memory: Encoded visual features
            device: Device to use
            max_len: Maximum sequence length
        
        Returns:
            Generated sequence embeddings
        """
        batch_size = memory.size(0)
        max_len = max_len or self.max_seq_length
        
        # Start with SOS token (assume index 1)
        generated = torch.ones(batch_size, 1).long().to(device)
        
        for _ in range(max_len - 1):
            tgt_emb = self.embedding(generated)
            tgt_emb = self.pos_encoder(tgt_emb)
            
            tgt_mask = self._generate_square_subsequent_mask(generated.size(1)).to(device)
            
            output = self.transformer_decoder(tgt_emb, memory, tgt_mask=tgt_mask)
            
            # Get next token
            next_token_logits = self.output_projection(output[:, -1:, :])
            next_token = next_token_logits.argmax(dim=-1)
            
            generated = torch.cat([generated, next_token], dim=1)
            
            # Stop if all sequences generated EOS (assume index 2)
            if (next_token == 2).all():
                break
        
        # Return the decoder outputs
        tgt_emb = self.embedding(generated)
        tgt_emb = self.pos_encoder(tgt_emb)
        tgt_mask = self._generate_square_subsequent_mask(generated.size(1)).to(device)
        output = self.transformer_decoder(tgt_emb, memory, tgt_mask=tgt_mask)
        
        return output


class PositionalEncoding(nn.Module):
    """Positional encoding for transformer."""
    
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 5000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-np.log(10000.0) / d_model))
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)


def train_epoch(model, dataloader, optimizer, criterion, device):
    """Train for one epoch."""
    model.train()
    total_loss = 0
    
    pbar = tqdm(dataloader, desc="Training")
    for images, target_seqs in pbar:
        images = images.to(device)
        target_seqs = target_seqs.to(device)
        
        # Forward pass
        logits = model(images, target_seqs[:, :-1])  # Teacher forcing
        
        # Compute loss
        logits_flat = logits.reshape(-1, logits.size(-1))
        targets_flat = target_seqs[:, 1:].reshape(-1)
        
        loss = criterion(logits_flat, targets_flat)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        
        total_loss += loss.item()
        pbar.set_postfix({'loss': f'{loss.item():.4f}'})
    
    return total_loss / len(dataloader)


def validate(model, dataloader, criterion, device, vocab):
    """Validate the model."""
    model.eval()
    total_loss = 0
    all_edit_distances = []
    all_cer = []
    
    with torch.no_grad():
        for images, target_seqs in tqdm(dataloader, desc="Validating"):
            images = images.to(device)
            target_seqs = target_seqs.to(device)
            
            # Forward pass
            logits = model(images, target_seqs[:, :-1])
            
            # Compute loss
            logits_flat = logits.reshape(-1, logits.size(-1))
            targets_flat = target_seqs[:, 1:].reshape(-1)
            loss = criterion(logits_flat, targets_flat)
            total_loss += loss.item()
            
            # Compute predictions
            predictions = logits.argmax(dim=-1)
            
            # Compute metrics
            for pred, target in zip(predictions, target_seqs[:, 1:]):
                pred_text = vocab.decode(pred.cpu().tolist())
                target_text = vocab.decode(target.cpu().tolist())
                
                edit_dist = compute_edit_distance(pred_text, target_text)
                cer = compute_cer(pred_text, target_text)
                
                all_edit_distances.append(edit_dist)
                all_cer.append(cer)
    
    avg_loss = total_loss / len(dataloader)
    avg_edit_dist = np.mean(all_edit_distances)
    avg_cer = np.mean(all_cer)
    
    return avg_loss, avg_edit_dist, avg_cer


def main():
    """Main training function."""
    # Load configuration
    config_path = Path(__file__).parent / "configs" / "ocr_tiny.yaml"
    with open(config_path) as f:
        config = yaml.safe_load(f)
    
    logger.info(f"Training OCR with config: {config}")
    
    # Setup
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"Using device: {device}")
    
    # Create datasets
    train_dataset = OCRDataset(
        data_dir=config['data']['train_dir'],
        augment=get_augmentation_pipeline('ocr'),
        max_seq_length=config['model']['max_seq_length']
    )
    
    val_dataset = OCRDataset(
        data_dir=config['data']['val_dir'],
        augment=None,
        max_seq_length=config['model']['max_seq_length']
    )
    
    vocab = train_dataset.vocab
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=True,
        num_workers=config['training']['num_workers'],
        collate_fn=train_dataset.collate_fn
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=False,
        num_workers=config['training']['num_workers'],
        collate_fn=val_dataset.collate_fn
    )
    
    # Create model
    model = TransformerOCR(
        vocab_size=len(vocab),
        d_model=config['model']['d_model'],
        nhead=config['model']['nhead'],
        num_encoder_layers=config['model']['num_encoder_layers'],
        num_decoder_layers=config['model']['num_decoder_layers'],
        dim_feedforward=config['model']['dim_feedforward'],
        dropout=config['model']['dropout'],
        max_seq_length=config['model']['max_seq_length']
    )
    model = model.to(device)
    
    # Loss and optimizer
    criterion = nn.CrossEntropyLoss(ignore_index=0)  # Ignore padding
    
    optimizer = optim.Adam(
        model.parameters(),
        lr=config['training']['learning_rate'],
        weight_decay=config['training']['weight_decay']
    )
    
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='min',
        factor=0.5,
        patience=3,
        verbose=True
    )
    
    # Training loop
    best_cer = float('inf')
    output_dir = Path(config['training']['output_dir'])
    output_dir.mkdir(parents=True, exist_ok=True)
    
    for epoch in range(config['training']['epochs']):
        logger.info(f"Epoch {epoch + 1}/{config['training']['epochs']}")
        
        # Train
        train_loss = train_epoch(model, train_loader, optimizer, criterion, device)
        logger.info(f"Train loss: {train_loss:.4f}")
        
        # Validate
        val_loss, val_edit_dist, val_cer = validate(model, val_loader, criterion, device, vocab)
        logger.info(f"Val loss: {val_loss:.4f}, Edit dist: {val_edit_dist:.2f}, CER: {val_cer:.4f}")
        
        # Learning rate scheduling
        scheduler.step(val_loss)
        
        # Save best model
        if val_cer < best_cer:
            best_cer = val_cer
            checkpoint_path = output_dir / "ocr_best.pth"
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_cer': val_cer,
                'vocab': vocab,
                'config': config
            }, checkpoint_path)
            logger.info(f"Saved best model with CER: {best_cer:.4f}")
        
        # Save checkpoint
        if (epoch + 1) % config['training']['save_interval'] == 0:
            checkpoint_path = output_dir / f"ocr_epoch_{epoch+1}.pth"
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_cer': val_cer,
                'vocab': vocab
            }, checkpoint_path)
    
    logger.info(f"Training completed! Best CER: {best_cer:.4f}")


if __name__ == "__main__":
    from ecg2signal.logging_conf import setup_logging
    setup_logging()
    main()
