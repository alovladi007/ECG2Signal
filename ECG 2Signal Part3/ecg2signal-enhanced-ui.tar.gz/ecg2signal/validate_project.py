#!/usr/bin/env python3
"""
Validation script to verify ECG2Signal project completeness.
"""
import sys
from pathlib import Path
from typing import List, Tuple

# Required files from specification
REQUIRED_FILES = [
    # Root
    "README.md",
    "LICENSE",
    "pyproject.toml",
    "requirements.txt",
    "Makefile",
    ".gitignore",
    ".env.example",
    
    # Main package
    "ecg2signal/__init__.py",
    "ecg2signal/types.py",
    "ecg2signal/config.py",
    "ecg2signal/logging_conf.py",
    
    # I/O
    "ecg2signal/io/pdf.py",
    "ecg2signal/io/image_io.py",
    "ecg2signal/io/dcm_waveform.py",
    "ecg2signal/io/fhir.py",
    "ecg2signal/io/wfdb_io.py",
    "ecg2signal/io/edf_io.py",
    
    # Preprocess
    "ecg2signal/preprocess/detect_page.py",
    "ecg2signal/preprocess/dewarp.py",
    "ecg2signal/preprocess/denoise.py",
    "ecg2signal/preprocess/grid_detect.py",
    "ecg2signal/preprocess/scale_calibrate.py",
    
    # Layout
    "ecg2signal/layout/lead_layout.py",
    "ecg2signal/layout/ocr_labels.py",
    
    # Segment
    "ecg2signal/segment/models/unet.py",
    "ecg2signal/segment/separate_layers.py",
    "ecg2signal/segment/trace_curve.py",
    
    # Reconstruct
    "ecg2signal/reconstruct/raster_to_signal.py",
    "ecg2signal/reconstruct/resample.py",
    "ecg2signal/reconstruct/align_leads.py",
    "ecg2signal/reconstruct/postprocess.py",
    
    # Clinical
    "ecg2signal/clinical/intervals.py",
    "ecg2signal/clinical/quality.py",
    "ecg2signal/clinical/reports.py",
    
    # Training
    "ecg2signal/training/data_synth/synth_ecg.py",
    "ecg2signal/training/data_synth/render.py",
    "ecg2signal/training/datasets.py",
    "ecg2signal/training/train_unet.py",
    "ecg2signal/training/train_layout.py",
    "ecg2signal/training/train_ocr.py",
    "ecg2signal/training/augment.py",
    "ecg2signal/training/metrics.py",
    "ecg2signal/training/configs/unet_small.yaml",
    "ecg2signal/training/configs/layout_cnn.yaml",
    "ecg2signal/training/configs/ocr_tiny.yaml",
    
    # API
    "ecg2signal/api/main.py",
    "ecg2signal/api/schemas.py",
    "ecg2signal/api/routes/__init__.py",
    "ecg2signal/api/routes/convert.py",
    "ecg2signal/api/routes/batch.py",
    "ecg2signal/api/routes/health.py",
    
    # CLI
    "ecg2signal/cli/ecg2signal.py",
    
    # UI
    "ecg2signal/ui/app.py",
    
    # Utils
    "ecg2signal/utils/viz.py",
    "ecg2signal/utils/timeit.py",
    "ecg2signal/utils/tempfile_utils.py",
    
    # Tests
    "tests/test_preprocess.py",
    "tests/test_grid_detect.py",
    "tests/test_scale_calibrate.py",
    "tests/test_layout_ocr.py",
    "tests/test_segmentation.py",
    "tests/test_trace.py",
    "tests/test_reconstruct.py",
    "tests/test_exports.py",
    "tests/test_api.py",
    
    # Docker
    "docker/Dockerfile",
    "docker/compose.yaml",
    
    # Scripts
    "scripts/download_demo_models.sh",
    "scripts/benchmark.sh",
    "scripts/export_onnx.py",
    
    # Docs
    "docs/index.md",
    "docs/usage.md",
    "docs/api.md",
    "docs/models.md",
    "docs/data_spec.md",
    "docs/calibration.md",
    "docs/clinical_metrics.md",
    "docs/compliance_security.md",
    "docs/roadmap.md",
]


def check_files(base_path: Path) -> Tuple[List[str], List[str]]:
    """
    Check which required files exist and which are missing.
    
    Returns:
        Tuple of (existing_files, missing_files)
    """
    existing = []
    missing = []
    
    for file_path in REQUIRED_FILES:
        full_path = base_path / file_path
        if full_path.exists():
            existing.append(file_path)
        else:
            missing.append(file_path)
    
    return existing, missing


def check_directories(base_path: Path) -> Tuple[List[str], List[str]]:
    """Check required directories."""
    required_dirs = [
        "ecg2signal/io",
        "ecg2signal/preprocess",
        "ecg2signal/layout",
        "ecg2signal/segment",
        "ecg2signal/segment/models",
        "ecg2signal/reconstruct",
        "ecg2signal/clinical",
        "ecg2signal/training",
        "ecg2signal/training/data_synth",
        "ecg2signal/training/configs",
        "ecg2signal/api",
        "ecg2signal/api/routes",
        "ecg2signal/cli",
        "ecg2signal/ui",
        "ecg2signal/ui/assets",
        "ecg2signal/utils",
        "tests",
        "tests/data",
        "tests/data/expected",
        "docker",
        "scripts",
        "docs",
    ]
    
    existing = []
    missing = []
    
    for dir_path in required_dirs:
        full_path = base_path / dir_path
        if full_path.exists() and full_path.is_dir():
            existing.append(dir_path)
        else:
            missing.append(dir_path)
    
    return existing, missing


def validate_imports():
    """Validate that key modules can be imported."""
    import_tests = [
        "ecg2signal",
        "ecg2signal.config",
        "ecg2signal.types",
        "ecg2signal.api.main",
        "ecg2signal.api.schemas",
    ]
    
    passed = []
    failed = []
    
    for module in import_tests:
        try:
            __import__(module)
            passed.append(module)
        except Exception as e:
            failed.append((module, str(e)))
    
    return passed, failed


def main():
    """Run validation checks."""
    print("=" * 70)
    print("ECG2Signal Project Validation")
    print("=" * 70)
    print()
    
    # Get project root
    base_path = Path(__file__).parent
    
    # Check files
    print("Checking required files...")
    existing_files, missing_files = check_files(base_path)
    print(f"✅ Found: {len(existing_files)}/{len(REQUIRED_FILES)} files")
    
    if missing_files:
        print(f"❌ Missing: {len(missing_files)} files")
        for file in missing_files[:10]:  # Show first 10
            print(f"   - {file}")
        if len(missing_files) > 10:
            print(f"   ... and {len(missing_files) - 10} more")
    else:
        print("✅ All required files present!")
    
    print()
    
    # Check directories
    print("Checking directory structure...")
    existing_dirs, missing_dirs = check_directories(base_path)
    print(f"✅ Found: {len(existing_dirs)} directories")
    
    if missing_dirs:
        print(f"❌ Missing: {len(missing_dirs)} directories")
        for dir in missing_dirs:
            print(f"   - {dir}")
    else:
        print("✅ All required directories present!")
    
    print()
    
    # Check test data
    print("Checking test data...")
    test_files = [
        "tests/data/sample_ecg_photo.jpg",
        "tests/data/sample_pdf.pdf",
        "tests/data/expected/lead_I.csv",
        "tests/data/expected/lead_II.csv",
    ]
    
    test_files_ok = all((base_path / f).exists() for f in test_files)
    if test_files_ok:
        print("✅ Test data files present")
    else:
        print("❌ Some test data files missing")
    
    print()
    
    # Check imports (optional, may fail without dependencies)
    print("Checking module imports...")
    try:
        passed_imports, failed_imports = validate_imports()
        if failed_imports:
            print(f"⚠️  Some imports failed (may need dependencies installed)")
            for module, error in failed_imports[:3]:
                print(f"   - {module}: {error[:50]}...")
        else:
            print("✅ All modules importable")
    except Exception as e:
        print(f"⚠️  Import check skipped: {e}")
    
    print()
    print("=" * 70)
    
    # Final summary
    total_checks = len(REQUIRED_FILES) + len(existing_dirs) + len(test_files)
    passed_checks = len(existing_files) + len(existing_dirs) + sum(1 for f in test_files if (base_path / f).exists())
    
    print(f"Overall: {passed_checks}/{total_checks} checks passed")
    
    if missing_files or missing_dirs:
        print("\n⚠️  Some files or directories are missing")
        return 1
    else:
        print("\n✅ Project structure complete!")
        return 0


if __name__ == "__main__":
    sys.exit(main())
