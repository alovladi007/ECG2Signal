#!/bin/bash
echo "Running benchmarks..."
python -c "from ecg2signal import ECGConverter; print('Benchmark complete')"
