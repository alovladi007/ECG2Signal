"""
Training script for lead layout detection CNN.

This model detects 12-lead panel regions and rhythm strip locations
from ECG images.
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from pathlib import Path
import yaml
from typing import Dict, Any
import logging
from tqdm import tqdm
import numpy as np

from ecg2signal.training.datasets import LayoutDataset
from ecg2signal.training.augment import get_augmentation_pipeline
from ecg2signal.training.metrics import compute_iou, compute_detection_metrics
from ecg2signal.config import get_settings

logger = logging.getLogger(__name__)


class LeadLayoutCNN(nn.Module):
    """
    Lightweight CNN for detecting lead panel regions.
    
    Architecture:
    - Encoder: ResNet-18 backbone (pretrained on ImageNet)
    - Decoder: FPN-style detection head
    - Output: Bounding boxes + class labels for each lead
    """
    
    def __init__(self, num_classes: int = 13):  # 12 leads + 1 rhythm strip
        super().__init__()
        
        # Use pretrained ResNet-18 as encoder
        import torchvision.models as models
        resnet = models.resnet18(pretrained=True)
        
        # Extract layers
        self.conv1 = resnet.conv1
        self.bn1 = resnet.bn1
        self.relu = resnet.relu
        self.maxpool = resnet.maxpool
        
        self.layer1 = resnet.layer1  # 64 channels
        self.layer2 = resnet.layer2  # 128 channels
        self.layer3 = resnet.layer3  # 256 channels
        self.layer4 = resnet.layer4  # 512 channels
        
        # Detection head
        self.detection_head = nn.Sequential(
            nn.Conv2d(512, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((7, 7)),
            nn.Flatten(),
            nn.Linear(128 * 7 * 7, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, num_classes * 5)  # 5 = (x, y, w, h, confidence)
        )
        
        self.num_classes = num_classes
    
    def forward(self, x):
        # Encoder
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        # Detection head
        detections = self.detection_head(x)
        
        # Reshape to (batch, num_classes, 5)
        detections = detections.view(-1, self.num_classes, 5)
        
        # Apply sigmoid to bounding box coords and confidence
        detections[:, :, :4] = torch.sigmoid(detections[:, :, :4])
        detections[:, :, 4] = torch.sigmoid(detections[:, :, 4])
        
        return detections


class LayoutLoss(nn.Module):
    """
    Combined loss for bounding box regression and confidence.
    """
    
    def __init__(self, lambda_coord: float = 5.0, lambda_noobj: float = 0.5):
        super().__init__()
        self.lambda_coord = lambda_coord
        self.lambda_noobj = lambda_noobj
        self.mse = nn.MSELoss(reduction='sum')
        self.bce = nn.BCELoss(reduction='sum')
    
    def forward(self, predictions, targets):
        """
        Args:
            predictions: (batch, num_classes, 5) - predicted boxes
            targets: (batch, num_classes, 5) - ground truth boxes
        """
        # Separate coordinates, dimensions, and confidence
        pred_xy = predictions[:, :, :2]
        pred_wh = predictions[:, :, 2:4]
        pred_conf = predictions[:, :, 4]
        
        target_xy = targets[:, :, :2]
        target_wh = targets[:, :, 2:4]
        target_conf = targets[:, :, 4]
        
        # Object mask (where confidence should be 1)
        obj_mask = (target_conf == 1.0)
        noobj_mask = (target_conf == 0.0)
        
        # Coordinate loss (only for existing objects)
        coord_loss = 0
        if obj_mask.sum() > 0:
            xy_loss = self.mse(pred_xy[obj_mask], target_xy[obj_mask])
            wh_loss = self.mse(torch.sqrt(pred_wh[obj_mask] + 1e-6),
                              torch.sqrt(target_wh[obj_mask] + 1e-6))
            coord_loss = self.lambda_coord * (xy_loss + wh_loss)
        
        # Confidence loss
        obj_conf_loss = self.bce(pred_conf[obj_mask], target_conf[obj_mask]) if obj_mask.sum() > 0 else 0
        noobj_conf_loss = self.lambda_noobj * self.bce(pred_conf[noobj_mask], target_conf[noobj_mask]) if noobj_mask.sum() > 0 else 0
        
        total_loss = coord_loss + obj_conf_loss + noobj_conf_loss
        
        return total_loss / predictions.size(0)


def train_epoch(model, dataloader, optimizer, criterion, device):
    """Train for one epoch."""
    model.train()
    total_loss = 0
    
    pbar = tqdm(dataloader, desc="Training")
    for images, targets in pbar:
        images = images.to(device)
        targets = targets.to(device)
        
        # Forward pass
        predictions = model(images)
        loss = criterion(predictions, targets)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        pbar.set_postfix({'loss': f'{loss.item():.4f}'})
    
    return total_loss / len(dataloader)


def validate(model, dataloader, criterion, device):
    """Validate the model."""
    model.eval()
    total_loss = 0
    all_ious = []
    
    with torch.no_grad():
        for images, targets in tqdm(dataloader, desc="Validating"):
            images = images.to(device)
            targets = targets.to(device)
            
            predictions = model(images)
            loss = criterion(predictions, targets)
            total_loss += loss.item()
            
            # Compute IoU for detected boxes
            for pred, target in zip(predictions, targets):
                for i in range(pred.size(0)):
                    if target[i, 4] > 0.5:  # Object exists
                        iou = compute_iou(
                            pred[i, :4].cpu().numpy(),
                            target[i, :4].cpu().numpy()
                        )
                        all_ious.append(iou)
    
    avg_loss = total_loss / len(dataloader)
    avg_iou = np.mean(all_ious) if all_ious else 0.0
    
    return avg_loss, avg_iou


def main():
    """Main training function."""
    # Load configuration
    config_path = Path(__file__).parent / "configs" / "layout_cnn.yaml"
    with open(config_path) as f:
        config = yaml.safe_load(f)
    
    logger.info(f"Training layout CNN with config: {config}")
    
    # Setup
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"Using device: {device}")
    
    # Create datasets
    train_dataset = LayoutDataset(
        data_dir=config['data']['train_dir'],
        augment=get_augmentation_pipeline('layout'),
        image_size=config['data']['image_size']
    )
    
    val_dataset = LayoutDataset(
        data_dir=config['data']['val_dir'],
        augment=None,
        image_size=config['data']['image_size']
    )
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=True,
        num_workers=config['training']['num_workers']
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=False,
        num_workers=config['training']['num_workers']
    )
    
    # Create model
    model = LeadLayoutCNN(num_classes=config['model']['num_classes'])
    model = model.to(device)
    
    # Loss and optimizer
    criterion = LayoutLoss(
        lambda_coord=config['loss']['lambda_coord'],
        lambda_noobj=config['loss']['lambda_noobj']
    )
    
    optimizer = optim.Adam(
        model.parameters(),
        lr=config['training']['learning_rate'],
        weight_decay=config['training']['weight_decay']
    )
    
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='min',
        factor=0.5,
        patience=5,
        verbose=True
    )
    
    # Training loop
    best_iou = 0
    output_dir = Path(config['training']['output_dir'])
    output_dir.mkdir(parents=True, exist_ok=True)
    
    for epoch in range(config['training']['epochs']):
        logger.info(f"Epoch {epoch + 1}/{config['training']['epochs']}")
        
        # Train
        train_loss = train_epoch(model, train_loader, optimizer, criterion, device)
        logger.info(f"Train loss: {train_loss:.4f}")
        
        # Validate
        val_loss, val_iou = validate(model, val_loader, criterion, device)
        logger.info(f"Val loss: {val_loss:.4f}, Val IoU: {val_iou:.4f}")
        
        # Learning rate scheduling
        scheduler.step(val_loss)
        
        # Save best model
        if val_iou > best_iou:
            best_iou = val_iou
            checkpoint_path = output_dir / "layout_cnn_best.pth"
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_iou': val_iou,
                'config': config
            }, checkpoint_path)
            logger.info(f"Saved best model with IoU: {best_iou:.4f}")
        
        # Save checkpoint
        if (epoch + 1) % config['training']['save_interval'] == 0:
            checkpoint_path = output_dir / f"layout_cnn_epoch_{epoch+1}.pth"
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_iou': val_iou
            }, checkpoint_path)
    
    logger.info(f"Training completed! Best IoU: {best_iou:.4f}")


if __name__ == "__main__":
    from ecg2signal.logging_conf import setup_logging
    setup_logging()
    main()
