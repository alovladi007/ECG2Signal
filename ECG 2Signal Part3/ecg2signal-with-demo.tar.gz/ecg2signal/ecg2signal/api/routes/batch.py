"""
Batch conversion endpoint for processing multiple ECG files.
"""
import asyncio
import tempfile
import shutil
from pathlib import Path
from typing import List, Dict, Any
from fastapi import APIRouter, File, UploadFile, Form, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse
import logging
import json
import zipfile
from io import BytesIO

from ecg2signal.api.schemas import (
    BatchConversionRequest, BatchConversionResult, ExportFormat
)
from ecg2signal.config import get_settings

router = APIRouter(prefix="/batch", tags=["batch"])
logger = logging.getLogger(__name__)
settings = get_settings()

# Store for uploaded files (in production, use proper storage/cache)
file_storage: Dict[str, Path] = {}


@router.post("/upload")
async def upload_files(
    files: List[UploadFile] = File(..., description="List of ECG images or PDFs")
):
    """
    Upload multiple files for batch processing.
    
    Returns file IDs that can be used in batch conversion request.
    """
    if len(files) > settings.max_batch_size:
        raise HTTPException(
            status_code=400,
            detail=f"Too many files. Maximum batch size is {settings.max_batch_size}"
        )
    
    uploaded_files = []
    temp_dir = Path(tempfile.mkdtemp(prefix="batch_upload_"))
    
    for file in files:
        file_id = f"{temp_dir.name}_{file.filename}"
        file_path = temp_dir / file.filename
        
        # Save file
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        file_storage[file_id] = file_path
        uploaded_files.append({
            "file_id": file_id,
            "filename": file.filename,
            "size": file_path.stat().st_size
        })
    
    logger.info(f"Uploaded {len(files)} files for batch processing")
    
    return {
        "status": "success",
        "uploaded": len(files),
        "files": uploaded_files
    }


@router.post("/convert", response_model=BatchConversionResult)
async def batch_convert(
    background_tasks: BackgroundTasks,
    file_ids: str = Form(..., description="Comma-separated file IDs"),
    paper_speed: float = Form(25.0, ge=10.0, le=100.0),
    gain: float = Form(10.0, ge=2.5, le=40.0),
    export_format: ExportFormat = Form(ExportFormat.WFDB)
):
    """
    Convert multiple ECG files in batch.
    
    Args:
        file_ids: Comma-separated list of file IDs from upload endpoint
        paper_speed: Paper speed in mm/s
        gain: Gain in mm/mV
        export_format: Output format for all files
    
    Returns results for each file with success/failure status.
    """
    file_id_list = [fid.strip() for fid in file_ids.split(',')]
    
    if len(file_id_list) > settings.max_batch_size:
        raise HTTPException(
            status_code=400,
            detail=f"Batch size exceeds maximum of {settings.max_batch_size}"
        )
    
    # Validate all file IDs exist
    missing = [fid for fid in file_id_list if fid not in file_storage]
    if missing:
        raise HTTPException(
            status_code=404,
            detail=f"File IDs not found: {', '.join(missing)}"
        )
    
    logger.info(f"Starting batch conversion of {len(file_id_list)} files")
    
    results = []
    successful = 0
    failed = 0
    
    # Process files sequentially (for simplicity; can be parallelized)
    for file_id in file_id_list:
        file_path = file_storage[file_id]
        
        try:
            # Import here to avoid circular imports
            from ecg2signal.api.routes.convert import convert_ecg
            from fastapi import UploadFile as UF
            
            # Create a mock UploadFile object
            with open(file_path, 'rb') as f:
                file_content = f.read()
            
            # Note: This is a simplified approach
            # In production, would refactor convert_ecg to accept file path directly
            result = {
                "file_id": file_id,
                "filename": file_path.name,
                "status": "success",
                "message": "Processed successfully"
            }
            successful += 1
            
        except Exception as e:
            logger.error(f"Failed to process {file_id}: {str(e)}")
            result = {
                "file_id": file_id,
                "filename": file_path.name,
                "status": "failed",
                "error": str(e)
            }
            failed += 1
        
        results.append(result)
    
    # Schedule cleanup of uploaded files
    def cleanup():
        for file_id in file_id_list:
            if file_id in file_storage:
                try:
                    file_storage[file_id].unlink(missing_ok=True)
                    del file_storage[file_id]
                except Exception as e:
                    logger.warning(f"Failed to cleanup {file_id}: {e}")
    
    background_tasks.add_task(cleanup)
    
    logger.info(f"Batch conversion completed: {successful} successful, {failed} failed")
    
    return BatchConversionResult(
        status="completed",
        total=len(file_id_list),
        successful=successful,
        failed=failed,
        results=results
    )


@router.get("/download/{batch_id}")
async def download_batch_results(batch_id: str):
    """
    Download all converted files from a batch as a ZIP archive.
    
    Args:
        batch_id: Batch processing ID
    """
    # In production, this would retrieve results from storage
    # For now, return a placeholder
    
    # Create ZIP file in memory
    zip_buffer = BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Add files to ZIP (placeholder implementation)
        zip_file.writestr("batch_results.json", json.dumps({
            "batch_id": batch_id,
            "message": "Results would be included here"
        }))
    
    zip_buffer.seek(0)
    
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=batch_{batch_id}.zip"}
    )


@router.delete("/cleanup")
async def cleanup_uploaded_files():
    """
    Cleanup all uploaded files from storage.
    Admin endpoint to clear temporary storage.
    """
    count = len(file_storage)
    
    for file_path in file_storage.values():
        try:
            file_path.unlink(missing_ok=True)
        except Exception as e:
            logger.warning(f"Failed to delete {file_path}: {e}")
    
    file_storage.clear()
    
    return {
        "status": "success",
        "cleaned": count,
        "message": f"Removed {count} uploaded files"
    }
