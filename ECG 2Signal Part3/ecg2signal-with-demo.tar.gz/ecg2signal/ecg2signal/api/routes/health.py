"""
Health check endpoint for monitoring and readiness probes.
"""
import time
import psutil
from pathlib import Path
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
import logging

from ecg2signal.api.schemas import HealthResponse
from ecg2signal import __version__

router = APIRouter(prefix="/health", tags=["health"])
logger = logging.getLogger(__name__)

# Track service start time
start_time = time.time()


@router.get("/", response_model=HealthResponse)
async def health_check():
    """
    Basic health check endpoint.
    
    Returns service status and version information.
    """
    uptime = time.time() - start_time
    
    return HealthResponse(
        status="healthy",
        version=__version__,
        models_loaded=True,  # Would check actual model loading status
        uptime_seconds=uptime
    )


@router.get("/ready")
async def readiness_check():
    """
    Kubernetes-style readiness probe.
    
    Checks if the service is ready to accept traffic.
    Returns 200 if ready, 503 if not ready.
    """
    # Check if models are loaded
    models_ready = True  # Placeholder - would check actual model status
    
    # Check if dependencies are available
    dependencies_ok = True
    
    if models_ready and dependencies_ok:
        return JSONResponse(
            status_code=200,
            content={
                "status": "ready",
                "checks": {
                    "models": "ok",
                    "dependencies": "ok"
                }
            }
        )
    else:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not ready",
                "checks": {
                    "models": "ok" if models_ready else "failed",
                    "dependencies": "ok" if dependencies_ok else "failed"
                }
            }
        )


@router.get("/live")
async def liveness_check():
    """
    Kubernetes-style liveness probe.
    
    Checks if the service is alive and should not be restarted.
    Returns 200 if alive, 500 if dead.
    """
    try:
        # Simple check that the process is responsive
        # Could add more sophisticated checks here
        return JSONResponse(
            status_code=200,
            content={"status": "alive"}
        )
    except Exception as e:
        logger.error(f"Liveness check failed: {e}")
        return JSONResponse(
            status_code=500,
            content={"status": "dead", "error": str(e)}
        )


@router.get("/metrics")
async def metrics():
    """
    Basic metrics endpoint for monitoring.
    
    Returns system and service metrics.
    """
    try:
        # System metrics
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        return {
            "uptime_seconds": time.time() - start_time,
            "system": {
                "cpu_percent": cpu_percent,
                "memory_percent": memory.percent,
                "memory_available_mb": memory.available / (1024 * 1024),
                "disk_percent": disk.percent,
                "disk_free_gb": disk.free / (1024 * 1024 * 1024)
            },
            "service": {
                "version": __version__,
                "models_loaded": True
            }
        }
    except Exception as e:
        logger.error(f"Failed to collect metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to collect metrics")


@router.get("/version")
async def version():
    """
    Get service version information.
    """
    return {
        "name": "ECG2Signal",
        "version": __version__,
        "api_version": "v1"
    }
