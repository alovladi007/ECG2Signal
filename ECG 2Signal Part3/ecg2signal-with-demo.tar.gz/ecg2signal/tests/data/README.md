# Test Data

This directory contains sample ECG files for testing.

## Files

- `sample_ecg_photo.jpg`: Synthetic ECG image with grid and sine wave
- `sample_pdf.pdf`: Sample ECG PDF report
- `expected/lead_I.csv`: Expected signal output for Lead I
- `expected/lead_II.csv`: Expected signal output for Lead II

## Format

CSV files have two columns:
- `sample`: Sample index (0-based)
- `value_mV`: Signal value in millivolts

Sampling rate: 500 Hz
Duration: 2 seconds
